library(testthat)
library(onlineFDR)

test_check("onlineFDR")
